import React from 'react'

function About() {
  return (
   <div className="container">
    <h1>Qoute Generator</h1>
    <h3>V 1.0</h3>
   </div>
  )
}

export default About